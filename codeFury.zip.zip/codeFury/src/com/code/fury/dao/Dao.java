package com.code.fury.dao;

import java.util.List;

import com.code.fury.exceptions.EntityAlreadyExistsException;

public interface Dao<T>{
	
	public boolean addDetails(T obj) throws EntityAlreadyExistsException;  //entity already exists exception
	public List<T> findAll();  
	public boolean remove(int id) throws EntityAlreadyExistsException; //element not found exception
	public boolean update(T obj) throws EntityAlreadyExistsException; //element not found exception
	public T findById(int id) throws EntityAlreadyExistsException; //element not found
}
