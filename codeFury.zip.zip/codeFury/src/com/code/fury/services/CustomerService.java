package com.code.fury.services;

import com.code.fury.dao.Dao;
import com.code.fury.model.Customer;
import com.code.fury.model.Product;
import com.code.fury.utils.ProductCategory;

public class CustomerService {
	
	private Dao<Customer> repo;
	static final int RATE = 10;
	
	private double getPrice(int id) {
		
		// select price from product where productid = id
		return 0.0;
	}
	public double gstCalculation(double price) {
		
		double gst=0.0;
		
		gst = (price * RATE)/100;
		return gst;
		
	}
	
	public double shippingCostCalculation(ProductCategory level,double orderValue) {
		
		double shippingCost = 0.0;
		
		if(orderValue > 100000) {
			shippingCost = 0.0;
		}else {
			if(level == ProductCategory.LEVEL_1) {
				
			}
		}
		
		return shippingCost;
	}
	
	

}

//values which we have to pass in service class while calculating gst and sc--> how to take these values
//1) we pass hard coded valye to the program or pass from db
