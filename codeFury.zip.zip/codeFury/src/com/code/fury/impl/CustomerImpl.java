package com.code.fury.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.code.fury.dao.Dao;
import com.code.fury.exceptions.EntityAlreadyExistsException;
import com.code.fury.model.Customer;

public class CustomerImpl implements Dao<Customer> {

	@Override
	public boolean addDetails(Customer obj) throws EntityAlreadyExistsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(int id) throws EntityAlreadyExistsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Customer obj) throws EntityAlreadyExistsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer findById(int id) throws EntityAlreadyExistsException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
