/**
 * 
 */
/**
 * 
 */
module codeFury {
	requires java.sql;
}