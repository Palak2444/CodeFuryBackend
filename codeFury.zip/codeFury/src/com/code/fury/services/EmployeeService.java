package com.code.fury.services;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import com.code.fury.dao.CustomerDao;
import com.code.fury.dao.EmployeeDao;
import com.code.fury.dao.OrderDao;
import com.code.fury.dao.ProductDao;
import com.code.fury.exceptions.EntityNotFoundException;
import com.code.fury.impl.CustomerImpl;
import com.code.fury.impl.EmployeeImpl;
import com.code.fury.model.Employee;
import com.code.fury.model.Order;
import com.code.fury.model.ProductsInsertionStatus;

public class EmployeeService  {

	private EmployeeDao employeeDao;
	private OrderDao orderDao;
	private ProductDao productDao;
	private CustomerDao customerDao;

	public EmployeeService() {

		employeeDao = new EmployeeImpl();
		orderDao = new OrderImpl();
		productDao = new ProductImpl();
		customerDao = new CustomerImpl();

	}

	public Employee login(int id, String password) throws EntityNotFoundException {
		// TODO Auto-generated method stub

		try {
			return employeeDao.login(id, password);
		} catch (EntityNotFoundException e) {
			e.printStackTrace();
		}
		throw new EntityNotFoundException("Employee does not exist",LocalDateTime.now(),"ERR107");

	}

	   public List<Order> getOrders() {

		List<Order> orderList = null;

		try {
			orderList = orderDao.getOrders();
			if (orderList.size() != 0)
				return orderList;
			// NULL pointer exception possible to be handled later

		} catch (NullPointerException e) {
			e.printStackTrace();
		}


	}

	 public ProductsInsertionStatus importProducts(String productJSON) {
		// TODO Auto-generated method stub

		ObjectMapper mapper = new ObjectMapper();
		try {
			List<Product> productList = Arrays
					.asList(mapper.readValue(Paths.get(productJSON).toFile(), Product[].class));

			Set<Product> hSet = new HashSet<Product>(productList);
			List<Product> finaProductsList = new ArrayList<Product>(hSet);

			return productDao.importProducts(finaProductsList);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	public String getProductData() {
		// TODO Auto-generated method stub

		return productDao.getAllProduct();
	}

	public String getCustomer(int id) throws EntityNotFoundException {
		// TODO Auto-generated method stub
		return customerDao.getCustomer(id);
	}

//	public String addQuote(String quote) {
//		
//		return null;
//	}


}