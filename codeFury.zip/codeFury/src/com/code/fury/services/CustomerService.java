package com.code.fury.services;

import java.time.LocalDateTime;

import com.code.fury.dao.CustomerDao;
import com.code.fury.dao.Dao;
import com.code.fury.dao.InvoiceDao;
import com.code.fury.exceptions.EntityNotFoundException;
import com.code.fury.impl.CustomerImpl;
import com.code.fury.model.Customer;
import com.code.fury.model.DetailedQuote;
import com.code.fury.model.Invoice;
import com.code.fury.model.Product;
import com.code.fury.utils.ProductCategory;

//public class CustomerService {
//	
//	private Dao<Customer> repo;
//	static final int RATE = 10;
//	
//	private double getPrice(int id) {
//		
//		// select price from product where productid = id
//		return 0.0;
//	}
//	public double gstCalculation(double price) {
//		
//		double gst=0.0;
//		
//		gst = (price * RATE)/100;
//		return gst;
//		
//	}
//	
//	public double shippingCostCalculation(ProductCategory level,double orderValue) {
//		
//		double shippingCost = 0.0;
//		
//		if(orderValue > 100000) {
//			shippingCost = 0.0;
//		}else {
//			if(level == ProductCategory.LEVEL_1) {
//				
//			}
//		}
//		
//		return shippingCost;
//	}
//	
//	//add implementations
//
//}
//
////values which we have to pass in service class while calculating gst and sc--> how to take these values
////1) we pass hard coded valye to the program or pass from db



public class CustomerService  {
	private CustomerDao cdao;
	private OrderDao orderDao;
	private InvoiceDao invoiceDao;

	// default constructor
	public CustomerService() {
		cdao = new CustomerImpl();
		orderDao = new OrderImpl();
		invoiceDao = new InvoiceImpl();
	}

	

	/*
	 * 
	 */
	public String getCustomer(int customerId) {
		try {
			return cdao.getCustomer(customerId);
		} catch (EntityNotFoundException e) {
			e.printStackTrace();
		}
		throw new EntityNotFoundException("Customer Not found",LocalDateTime.now(),"ERR102");
	}

	
	public String displayQuote(int customerId) {
		try {
			return orderDao.displayQuoteDetails(customerId);
		} catch (EntityNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		throw new EntityNotFoundException("Quote Not found",LocalDateTime.now(),"ERR104");
	}

	public void changeQuoteStatus(int orderId) {
		orderDao.setQuoteStatus(orderId);

	}


	public String displayOrder(int customerId) {
		try {
			return orderDao.displayOrderDetails(customerId);
		} catch (EntityNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		throw new EntityNotFoundException("Customer Not Exists",LocalDateTime.now(),"ERR106");
	}

	
	public Invoice showInvoice(int orderId) {
		return invoiceDao.displayOrderInvoice(orderId);
	}

	/*
	 * Method to use OrderDaoImpl object and pass specific order id to display
	 * detailed quote method in OrderDaoImpl and return Array List of type Object
	 * containing objects of type Order and Customer.
	 */
	
	public DetailedQuote displayAllQuoteDetails(String orderId) {
		try {
			return orderDao.displayDetailedQuote(orderId);
		} catch (EntityNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		throw new EntityNotFoundException("Order Not found",LocalDateTime.now(),"ERR105");
	}

}
