package com.code.fury.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.code.fury.dao.InvoiceDao;
import com.code.fury.model.Customer;
import com.code.fury.model.Invoice;
import com.code.fury.model.Order;
import com.code.fury.model.ProductDetails;

public class InvoiceImpl implements InvoiceDao {

	private Connection con;
	
	public static final String FINDALL ="select * from Invoice";
	
	public InvoiceImpl(Connection con) {
		super();
		this.con = con;
	}

	@Override
	public Invoice displayInvoices(int orderId) {
		// TODO Auto-generated method stub
		List<Invoice>;

		return null;
	}
	
	
	

}
