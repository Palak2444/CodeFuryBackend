package com.code.fury.dao;

public interface ProductDao {

}
