package com.code.fury.dao;

import com.code.fury.model.Invoice;

public interface InvoiceDao {
	
	public Invoice displayInvoices(int orderId);


}
