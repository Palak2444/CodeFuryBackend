package com.code.fury.utils;

public enum Status {
	COMPLETED,
	PARTIAL,
	FAILED

}
