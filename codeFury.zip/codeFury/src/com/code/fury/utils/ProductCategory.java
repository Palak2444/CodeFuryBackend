package com.code.fury.utils;

public enum ProductCategory {
	
	LEVEL_1,
    LEVEL_2,
    LEVEL_3

}
